import 'package:e_store/core/generated/app_assets.dart';
import 'package:e_store/core/theme/app_colors.dart';
import 'package:e_store/core/theme/app_spacing.dart';
import 'package:e_store/core/theme/app_text_styles.dart';
import 'package:e_store/core/translations/locale_keys.dart';
import 'package:e_store/features/main_layout/presentation/cubit/cubit/bottom_nav_cubit.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CustomBottomNavBar extends StatelessWidget {
  const CustomBottomNavBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.space8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 20,
            offset: Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _item(
            context,
            index: 0,
            icon: AppAssets.svgHomeBtBarIcon,
            label: LocaleKeys.home.tr(),
          ),

          _item(
            context,
            index: 1,
            icon: AppAssets.svgCoursesBtBarIcon,
            label: LocaleKeys.courses.tr(),
          ),

          _item(
            context,
            index: 2,
            icon: AppAssets.svgAchievementsBtBarIcon,
            label: LocaleKeys.achievements.tr(),
          ),

          _item(
            context,
            index: 3,
            icon: AppAssets.svgSocietyBtBarIcon,
            label: LocaleKeys.community.tr(),
          ),

          _item(
            context,
            index: 4,
            icon: AppAssets.svgProfile,
            label: LocaleKeys.profile.tr(),
          ),
        ],
      ),
    );
  }

  Widget _item(
    BuildContext context, {
    required int index,
    required String icon,
    required String label,
  }) {
    final cubit = context.read<BottomNavCubit>();

    final currentIndex = context.watch<BottomNavCubit>().state.currentIndex;

    final isSelected = currentIndex == index;

    return GestureDetector(
      onTap: () {
        cubit.changeBottomNav(index);
      },

      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),

        padding: const EdgeInsets.symmetric(
          vertical: AppSpacing.space8,
          horizontal: AppSpacing.space8,
        ),

        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.backgroundShadowSelected
              : Colors.transparent,

          borderRadius: BorderRadius.circular(16),
        ),

        child: Column(
          mainAxisSize: MainAxisSize.min,

          children: [
            SvgPicture.asset(
              icon,
              colorFilter: isSelected
                  ? ColorFilter.mode(AppColors.leanerEnd, BlendMode.srcIn)
                  : null,
            ),

            const SizedBox(height: 4),

            Text(
              label,

              style: AppTextStyles.title14SemiBlod.copyWith(
                color: isSelected ? AppColors.leanerEnd : Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
