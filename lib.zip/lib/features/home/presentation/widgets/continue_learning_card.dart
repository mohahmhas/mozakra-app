import 'package:e_store/core/generated/app_assets.dart';
import 'package:e_store/core/shared/helpers/spacing.dart';
import 'package:e_store/core/theme/app_colors.dart';
import 'package:e_store/core/theme/app_radius.dart';
import 'package:e_store/core/theme/app_text_styles.dart';
import 'package:e_store/core/translations/locale_keys.dart';
import 'package:e_store/features/home/data/model/continue_learning_course.dart';
import 'package:e_store/features/home/presentation/widgets/course_progress_bar.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';

class ContinueLearningCard extends StatelessWidget {
  const ContinueLearningCard({super.key, required this.course, this.onTap});

  final ContinueLearningCourse course;
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 350.w,
      height: 224.h,
      padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 24.h),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.leanerEnd, AppColors.leanerMed],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppRadius.radius20),
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          Container(
            width: 55.w,
            height: 24.h,
            padding: EdgeInsets.symmetric(vertical: 4.h, horizontal: 8.w),
            decoration: BoxDecoration(
              color: AppColors.white.withValues(alpha: 0.20),
              borderRadius: BorderRadius.circular(AppRadius.radius13),
            ),
            child: Text(
              LocaleKeys.progress.tr(),
              style: AppTextStyles.title12BlodWhite,
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            course.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppTextStyles.title18BlodWhite,
          ),

          SizedBox(height: 4.h),

          Text(
            course.decription,
            style: AppTextStyles.bodyMedium.copyWith(color: AppColors.white),
          ),

          verticalSpace(20.h),

          CourseProgressBar(progress: course.progress),
          verticalSpace(20.h),

          InkWell(
            onTap: onTap,
            child: Container(
              width: 161.w,
              height: 42.h,
              padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 24.w),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(AppRadius.radius12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SvgPicture.asset(
                    AppAssets.svgPlayer,
                    width: 16.w,
                    height: 16.h,
                  ),
                  SizedBox(width: 8.w),
                  Text(
                    LocaleKeys.continueText.tr(),
                    style: AppTextStyles.title18SemiBlod.copyWith(
                      color: AppColors.leanerEnd,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
