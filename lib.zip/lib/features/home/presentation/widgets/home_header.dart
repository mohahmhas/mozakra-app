import 'package:e_store/core/theme/app_text_styles.dart';
import 'package:e_store/core/translations/locale_keys.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class HomeHeader extends StatelessWidget {
  final String? userName;
  const HomeHeader({super.key, this.userName});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
              userName == null
                  ? Text(
                      '${LocaleKeys.hi.tr()} 👋',
                      style: AppTextStyles.headlineLarge,
                    )
                  : Text(
                      '${LocaleKeys.hi.tr()} ${userName!} 👋',
                      style: AppTextStyles.headlineLarge,
                    ),
              Text(
                LocaleKeys.keepUpTheGoodWork.tr(),
                style: AppTextStyles.bodyMedium,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
