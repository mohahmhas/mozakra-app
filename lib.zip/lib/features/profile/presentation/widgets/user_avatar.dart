import 'package:e_store/core/theme/app_colors.dart';
import 'package:e_store/core/theme/app_spacing.dart';
import 'package:e_store/core/theme/app_text_styles.dart';
import 'package:e_store/features/profile/presentation/widgets/type_student.dart';
import 'package:flutter/material.dart';

class UserAvatar extends StatelessWidget {
  const UserAvatar({
    super.key,

    this.imageUrl,

    this.name,

    this.radius = 28,

    this.backgroundColor,

    this.textColor,

    this.onTap,

    this.borderColor,

    this.borderWidth = 0,

    this.assetImage,

    this.isNetworkImage = false,
  });

  final String? imageUrl;

  final String? assetImage;

  final String? name;

  final double radius;

  final Color? backgroundColor;

  final Color? textColor;

  final VoidCallback? onTap;

  final Color? borderColor;

  final double borderWidth;

  final bool isNetworkImage;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: AppSpacing.space136,
      child: Stack(
        children: [
          GestureDetector(
            onTap: onTap,
            child: Container(
              width: AppSpacing.space120,
              height: AppSpacing.space120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: backgroundColor ?? Colors.red, //AppColors.lightGrey,
                border: borderWidth > 0
                    ? Border.all(
                        color: borderColor ?? Colors.white,

                        width: borderWidth,
                      )
                    : null,
              ),

              child: _hasImage
                  ? Container(
                      child: isNetworkImage
                          ? Image.network(
                              imageUrl!,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => _buildInitial(),
                            )
                          : Image.asset(assetImage!, fit: BoxFit.cover),
                    )
                  : _buildInitial(),
            ),
          ),
          Positioned(
            top: 90,
            left: AppSpacing.space8,
            right: AppSpacing.space8,
            child: TypeStudent(),
          ),
        ],
      ),
    );
  }

  bool get _hasImage {
    return (imageUrl != null && imageUrl!.isNotEmpty) ||
        (assetImage != null && assetImage!.isNotEmpty);
  }

  Widget _buildInitial() {
    return Container(
      width: AppSpacing.space120,
      height: AppSpacing.space120,
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        shape: BoxShape.rectangle,
        borderRadius: BorderRadius.circular(AppSpacing.space10),
      ),
      child: Center(
        child: Text(
          _initialLetter,
          style: AppTextStyles.titleMedium.copyWith(
            color: textColor ?? AppColors.black,
          ),
        ),
      ),
    );
  }

  String get _initialLetter {
    if (name == null || name!.isEmpty) {
      return '?';
    }

    return name!.trim().characters.first.toUpperCase();
  }
}
