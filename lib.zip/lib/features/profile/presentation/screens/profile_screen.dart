import 'package:e_store/core/generated/app_assets.dart';
import 'package:e_store/core/router/routes.dart';
import 'package:e_store/core/shared/helpers/extensions.dart';
import 'package:e_store/core/shared/widgets/custom_app_bar.dart';
import 'package:e_store/core/shared/widgets/title_app.dart';
import 'package:e_store/core/theme/app_colors.dart';
import 'package:e_store/core/theme/app_radius.dart';
import 'package:e_store/core/theme/app_spacing.dart';
import 'package:e_store/core/theme/app_text_styles.dart';
import 'package:e_store/core/translations/locale_keys.dart';
import 'package:e_store/features/profile/presentation/widgets/profile_menu_tile.dart';
import 'package:e_store/features/profile/presentation/widgets/user_avatar.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:go_router/go_router.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: CustomAppBar(
          actions: [
            SizedBox(width: AppSpacing.space8),
            TitleApp(),
            Spacer(),
            Container(
              width: AppSpacing.space36,
              height: AppSpacing.space36,
              decoration: BoxDecoration(
                color: Colors.grey,
                shape: BoxShape.circle,
              ),

              padding: const EdgeInsets.all(8.0),

              child: Center(child: Text('A')),
            ),
            SizedBox(width: AppSpacing.space10),
            Icon(Icons.notifications_none_outlined, size: AppSpacing.space36),
            SizedBox(width: AppSpacing.space10),
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(height: AppSpacing.space36),
              UserAvatar(name: 'Ahmed Mohamed'),
              SizedBox(height: AppSpacing.space20),
              Text('Ahmed Mohamed', style: AppTextStyles.displayLarge),
              Text(
                'Software Engineering Student - Level 3',
                style: AppTextStyles.bodyMedium,
              ),
              SizedBox(height: AppSpacing.space36),

              //------------------------------------------------------------------
              ProfileMenuTile(
                title: LocaleKeys.profileInfo.tr(),
                iconPath: AppAssets.svgProfile,
              ),
              ProfileMenuTile(
                title: LocaleKeys.myEducationalCertificate.tr(),
                iconPath: AppAssets.svgCertificationIcon,
              ),
              ProfileMenuTile(
                title: LocaleKeys.paymentMethods.tr(),
                iconPath: AppAssets.svgPaymentIcon,
              ),
              ProfileMenuTile(
                title: LocaleKeys.settings.tr(),
                iconPath: AppAssets.svgSettingIcon,
                onTap: () {
                  context.push(Routes.settings);
                },
              ),
              ProfileMenuTile(
                title: LocaleKeys.logOut.tr(),
                iconPath: context.isArabic
                    ? AppAssets.svgLogoutIconEn
                    : AppAssets.svgLogoutIconAr,
              ),
              // ------------------------------------------------------------------
              SizedBox(height: AppSpacing.space32),
              Stack(
                children: [
                  Container(
                    width: AppSpacing.space350,
                    height: AppSpacing.space190,
                    padding: EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(AppRadius.radius24),
                      gradient: LinearGradient(
                        colors: [
                          AppColors.leanerMed,
                          AppColors.leanerStartAssestantBox,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          LocaleKeys.doYouNeedHelp.tr(),
                          style: AppTextStyles.title24SemiBlod,
                        ),
                        SizedBox(height: AppSpacing.space4),
                        Text(
                          LocaleKeys.askOurSmartAssistantAboutCourses.tr(),
                          style: AppTextStyles.bodyMedium.copyWith(
                            color: AppColors.white,
                            height: 1.5,
                          ),
                        ),
                        SizedBox(height: AppSpacing.space16),

                        Container(
                          width: 270.w,
                          height: 45.h,
                          padding: EdgeInsets.symmetric(
                            horizontal: AppSpacing.space21,
                            vertical: AppSpacing.space10,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.white,
                            borderRadius: BorderRadius.circular(
                              AppRadius.radius20,
                            ),
                          ),
                          child: Row(
                            children: [
                              SvgPicture.asset(
                                height: 19.h,
                                AppAssets.svgSmartAssistant,
                                fit: BoxFit.scaleDown,
                              ),
                              SizedBox(width: AppSpacing.space8),
                              Text(
                                LocaleKeys.talkWithAssistant.tr(),
                                style: AppTextStyles.title18SemiBlod.copyWith(
                                  color: AppColors.leanerEnd,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: 70,
                    left: 3,
                    child: SizedBox(
                      width: 95,
                      height: 100,
                      child: SvgPicture.asset(
                        fit: BoxFit.scaleDown,
                        context.isArabic
                            ? AppAssets.svgHumanAssestAr
                            : AppAssets.svgHumanAssestEn,
                        colorFilter: ColorFilter.mode(
                          AppColors.white.withValues(alpha: 0.5),
                          BlendMode.srcIn,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: AppSpacing.space45),
            ],
          ),
        ),
      ),
    );
  }
}
