import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'achivements_state.dart';

class AchivementsCubit extends Cubit<AchivementsState> {
  AchivementsCubit() : super(AchivementsInitial());
}
