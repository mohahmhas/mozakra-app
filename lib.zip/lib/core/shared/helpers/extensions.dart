import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:timeago/timeago.dart' as timeago;

extension ContextExtension on BuildContext {
  bool get isArabic => locale.languageCode == 'ar';
}

extension AppThemeContext on BuildContext {
  Color get colorsBorder => Theme.of(this).colorScheme.outline;
  Color get background => Theme.of(this).scaffoldBackgroundColor;

  Color get surface => Theme.of(this).colorScheme.surface;

  Color get onSurface => Theme.of(this).colorScheme.onSurface;

  Color get primary => Theme.of(this).colorScheme.primary;
  Color get divider => Theme.of(this).dividerColor;

  Color get error => Theme.of(this).colorScheme.error;
}

extension AppTextColor on BuildContext {
  Color get textPrimary => Theme.of(this).colorScheme.onSurface;

  Color get textSecondary => Theme.of(this).colorScheme.onSurface;

  Color get textHint =>
      Theme.of(this).colorScheme.onSurface.withValues(alpha: .5);
}

extension DateTimeExtension on DateTime {
  String timeAgo({String locale = 'en'}) {
    return timeago.format(this, locale: locale);
  }
}
