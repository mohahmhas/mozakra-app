import 'package:e_store/core/shared/widgets/title_app.dart';
import 'package:e_store/core/theme/app_text_styles.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  const CustomAppBar({
    super.key,

    this.title,
    this.titleApp = false,
    this.centerTitle = true,

    this.leading,

    this.actions,

    this.showBackButton = false,

    this.onBackPressed,
  });

  final String? title;
  final bool titleApp;

  final bool centerTitle;

  final Widget? leading;

  final List<Widget>? actions;

  final bool showBackButton;

  final VoidCallback? onBackPressed;

  @override
  Size get preferredSize => Size.fromHeight(65.h);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false,

      elevation: 0,

      scrolledUnderElevation: 0,

      backgroundColor: Theme.of(context).appBarTheme.backgroundColor,

      centerTitle: centerTitle,

      toolbarHeight: 65.h,

      leading: showBackButton
          ? IconButton(
              onPressed: onBackPressed ?? () => Navigator.pop(context),

              icon: Icon(
                Icons.arrow_back_ios_new_rounded,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            )
          : leading,

      title: titleApp
          ? TitleApp()
          : title != null
          ? Text(title!, style: AppTextStyles.titleMedium)
          : null,

      actions: actions,
    );
  }
}
